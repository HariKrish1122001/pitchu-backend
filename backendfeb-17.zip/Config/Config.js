let config = {
  DollerpriceApi : "https://api.exchangerate-api.com/v4/latest/usd",
  FrontEnd_Url:"http://localhost:3000/",
 
 
};

module.exports = config;
